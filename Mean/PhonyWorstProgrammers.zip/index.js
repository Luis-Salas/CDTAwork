var arr = [1,4,2,-5,-2,19]

function noNeg(arr){
	for(var i = 0; i< arr.length; i++){
		if(arr[i] < 0){
			return false
		}
	}
	return true
}
console.log(noNeg(arr))

function isEven(int){
	if(int % 2 == 0){
		return true
	}
	return false
}

console.log(isEven(4))

function howManyEven(array){
	var pos = 0
	var neg = 0
	for(var i = 0;i < arr.length; i++){
		var output = isEven(arr[i])
		console.log(arr[i], "i")
		if(output == true){
			pos++
			console.log(pos)

		}
	}
	return pos
}

console.log(howManyEven(arr))


function dummyArr(int){
	var newArr = []
	var i = 0
	while(i < int){
	newArr.push(Math.floor(Math.random() * 10))
	i++
	}
	return newArr
}

console.log(dummyArr(5));
