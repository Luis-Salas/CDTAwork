// var arr = [4, 6, 1, 3, 5, 7, 25]
// function starString(arr){
// 	var print = "*"
// 	for(var i = 0; i < arr.length; i++){
// 	console.log(print.repeat(arr[i]))
// 	}
// }
// starString(arr)

var arr = [4, "test", 1, "hello", 5, 7, 25]
function starString(arr){
	var print = "*"
	for(var i = 0; i < arr.length; i++){
		var varType = typeof arr[i]
		if(varType == "string"){
			var first_val = arr[i].charAt(0)
			console.log(first_val.repeat(arr[i].length))
		}
		else{
			console.log(print.repeat(arr[i]))
		}
	}
}
starString(arr)