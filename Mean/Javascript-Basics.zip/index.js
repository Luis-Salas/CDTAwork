var x = []
x.push('coding', 'dojo', 'rocks')
x.pop()
console.log(x);

const Y = []
Y.push(88)
console.log(Y)

var z = [9, 10, 6, 5, -1, 20, 13, 2]
for(var i = 0; i < z.length -1; i++){
	console.log(z[i])
}

var names = ['Kadie', 'Joe', 'Fritz', 'Pierre', 'Alphonso']
for(var i = 0; i < names.length -1; i++){
	if(names[i].length >= 5){
	console.log(names[i].length)
		
	}
}

function yell(str){
	var upCase = str.toUpperCase()
	return upCase
}
x = yell("hello")
console.log(x)