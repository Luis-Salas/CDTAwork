from django.apps import AppConfig


class StartAppConfig(AppConfig):
    name = 'start_app'
